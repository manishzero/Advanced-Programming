package com.onboarding;

/**
 * Checked exception thrown when an email address is null, empty, or
 * does not conform to the standard email format.
 *
 * Being a checked exception (extends Exception), callers are forced by
 * the compiler to handle or declare it — appropriate for a recoverable
 * input-validation error.
 */
public class InvalidEmailException extends Exception {

    private final String email;

    public InvalidEmailException(String email) {
        super(buildMessage(email));
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    private static String buildMessage(String email) {
        if (email == null || email.isEmpty()) {
            return "Email address must not be null or empty.";
        }
        return String.format(
            "'%s' is not a valid email address. "
            + "Expected format: identifier@domain.tld", email
        );
    }
}
