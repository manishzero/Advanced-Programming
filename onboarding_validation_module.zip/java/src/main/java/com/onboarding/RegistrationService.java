package com.onboarding;

import java.util.regex.Pattern;

/**
 * Core validation service for the user onboarding module.
 *
 * <p>Business rules enforced:
 * <ol>
 *   <li>Email must not be {@code null} or empty.</li>
 *   <li>Email must match the standard format:
 *       {@code ^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$}</li>
 *   <li>Applicant must be at least 18 years old.</li>
 * </ol>
 */
public class RegistrationService {

    // Standard email regex pattern (as defined in slides)
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9._%+\\-]+"   // local part (identifier)
        + "@"                      // @ symbol (mandatory separator)
        + "[a-zA-Z0-9.\\-]+"      // domain name
        + "\\.[a-zA-Z]{2,}$"      // top-level domain (min 2 chars)
    );

    private static final int MINIMUM_AGE = 18;

    /** When false, the service refuses to process registrations (used for assert). */
    private final boolean enabled;

    public RegistrationService(boolean enabled) {
        this.enabled = enabled;
    }

    /** Convenience constructor — creates an enabled service. */
    public RegistrationService() {
        this(true);
    }

    // ──────────────────────────────────────────────────────────────────
    // Public API
    // ──────────────────────────────────────────────────────────────────

    /**
     * Validate the supplied {@code email} and {@code age}, then approve
     * or deny the registration.
     *
     * @param email Applicant's e-mail address.
     * @param age   Applicant's age in years.
     * @return {@code true} if registration succeeds.
     * @throws InvalidEmailException if the email is absent or malformed (checked).
     * @throws UnderageException     if the applicant is under 18 (unchecked).
     */
    public boolean registerUser(String email, int age) throws InvalidEmailException {

        // ── Internal invariant ──────────────────────────────────────
        // Asserts that the service is enabled before any processing.
        // NOTE: assertions must be enabled at runtime with -ea flag.
        assert enabled : "RegistrationService is currently disabled; "
                         + "cannot process registrations.";

        // ── Rule 1 & 2: Email validation ────────────────────────────
        validateEmail(email);

        // ── Rule 3: Age validation ──────────────────────────────────
        validateAge(age);

        // All checks passed → registration approved
        return true;
    }

    // ──────────────────────────────────────────────────────────────────
    // Private helpers
    // ──────────────────────────────────────────────────────────────────

    private void validateEmail(String email) throws InvalidEmailException {
        if (email == null || email.isEmpty()) {
            throw new InvalidEmailException(email);
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new InvalidEmailException(email);
        }
    }

    private void validateAge(int age) {
        if (age < MINIMUM_AGE) {
            throw new UnderageException(age);
        }
    }
}
