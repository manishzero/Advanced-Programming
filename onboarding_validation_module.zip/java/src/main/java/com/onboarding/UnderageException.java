package com.onboarding;

/**
 * Unchecked exception thrown when an applicant does not meet the
 * minimum age requirement of 18 years.
 *
 * Being an unchecked exception (extends RuntimeException), it signals
 * a programming/policy violation that callers are not required to
 * explicitly catch — but can if they choose to.
 */
public class UnderageException extends RuntimeException {

    public static final int MINIMUM_AGE = 18;
    private final int age;

    public UnderageException(int age) {
        super(String.format(
            "Applicant age %d does not meet the minimum age requirement "
            + "of %d. Registration denied.", age, MINIMUM_AGE
        ));
        this.age = age;
    }

    public int getAge() {
        return age;
    }
}
