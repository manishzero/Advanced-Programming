package com.onboarding;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 test suite for {@link RegistrationService}.
 *
 * <p>Test categories:
 * <ul>
 *   <li>Successful registration (happy path)</li>
 *   <li>{@link InvalidEmailException} triggers</li>
 *   <li>{@link UnderageException} triggers</li>
 *   <li>Exception hierarchy / inheritance</li>
 *   <li>Internal assert / invariant</li>
 * </ul>
 */
@DisplayName("RegistrationService Test Suite")
class RegistrationServiceTest {

    private RegistrationService service;

    // ── Shared setup — runs before every single test ─────────────────

    @BeforeEach
    void setUp() {
        service = new RegistrationService(true);   // fresh, enabled instance
    }

    // ══════════════════════════════════════════════════════════════════
    // Happy-path tests
    // ══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Successful Registration")
    class SuccessfulRegistrationTests {

        @Test
        @DisplayName("Valid email and adult age returns true")
        void validEmailAndAdultAge() throws InvalidEmailException {
            assertTrue(service.registerUser("alice@example.com", 25));
        }

        @Test
        @DisplayName("Exactly age 18 (boundary) is accepted")
        void minimumAgeBoundaryIsAccepted() throws InvalidEmailException {
            assertTrue(service.registerUser("bob@domain.org", 18));
        }

        @Test
        @DisplayName("Email with plus-tag is valid")
        void emailWithPlusTagIsValid() throws InvalidEmailException {
            assertTrue(service.registerUser("user+tag@mail.co", 30));
        }

        @Test
        @DisplayName("Email with subdomain is valid")
        void emailWithSubdomainIsValid() throws InvalidEmailException {
            assertTrue(service.registerUser("name@sub.domain.com", 22));
        }

        @Test
        @DisplayName("Email with dots in local part is valid")
        void emailWithDotsInLocalPartIsValid() throws InvalidEmailException {
            assertTrue(service.registerUser("first.last@company.io", 40));
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // InvalidEmailException tests
    // ══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("InvalidEmailException Scenarios")
    class InvalidEmailExceptionTests {

        @Test
        @DisplayName("Empty string throws InvalidEmailException")
        void emptyEmailThrows() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser("", 25));
        }

        @Test
        @DisplayName("Null email throws InvalidEmailException")
        void nullEmailThrows() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser(null, 25));
        }

        @Test
        @DisplayName("Missing @ symbol throws InvalidEmailException")
        void missingAtSymbolThrows() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser("invalidemail.com", 25));
        }

        @Test
        @DisplayName("Missing domain throws InvalidEmailException")
        void missingDomainThrows() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser("user@", 25));
        }

        @Test
        @DisplayName("Missing TLD throws InvalidEmailException")
        void missingTldThrows() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser("user@domain", 25));
        }

        @Test
        @DisplayName("Double @ symbol throws InvalidEmailException")
        void doubleAtThrows() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser("user@@domain.com", 25));
        }

        @Test
        @DisplayName("Spaces in email throw InvalidEmailException")
        void spacesInEmailThrow() {
            assertThrows(InvalidEmailException.class,
                () -> service.registerUser("user @domain.com", 25));
        }

        @Test
        @DisplayName("Exception message contains the bad email address")
        void exceptionMessageContainsBadEmail() {
            String badEmail = "not-an-email";
            InvalidEmailException ex = assertThrows(InvalidEmailException.class,
                () -> service.registerUser(badEmail, 25));
            assertTrue(ex.getMessage().contains(badEmail));
        }

        @Test
        @DisplayName("Exception message for null/empty describes the constraint")
        void exceptionMessageForEmptyDescribesConstraint() {
            InvalidEmailException ex = assertThrows(InvalidEmailException.class,
                () -> service.registerUser("", 25));
            assertTrue(ex.getMessage().toLowerCase().contains("null") ||
                       ex.getMessage().toLowerCase().contains("empty"));
        }

        @Test
        @DisplayName("InvalidEmailException is a checked Exception")
        void isCheckedExceptionSubtype() {
            Exception ex = assertThrows(InvalidEmailException.class,
                () -> service.registerUser("bad", 25));
            assertInstanceOf(Exception.class, ex);
            // Verified at compile-time: registerUser declares 'throws InvalidEmailException'
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // UnderageException tests
    // ══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("UnderageException Scenarios")
    class UnderageExceptionTests {

        @Test
        @DisplayName("Age 17 throws UnderageException")
        void age17Throws() {
            assertThrows(UnderageException.class,
                () -> service.registerUser("valid@example.com", 17));
        }

        @Test
        @DisplayName("Age 0 throws UnderageException")
        void age0Throws() {
            assertThrows(UnderageException.class,
                () -> service.registerUser("valid@example.com", 0));
        }

        @Test
        @DisplayName("Negative age throws UnderageException")
        void negativeAgeThrows() {
            assertThrows(UnderageException.class,
                () -> service.registerUser("valid@example.com", -5));
        }

        @Test
        @DisplayName("Boundary: age 17 (one below minimum) throws")
        void boundaryOneBelowMinimumThrows() {
            assertThrows(UnderageException.class,
                () -> service.registerUser("valid@example.com", 17));
        }

        @Test
        @DisplayName("Exception message contains the supplied age")
        void exceptionMessageContainsAge() {
            UnderageException ex = assertThrows(UnderageException.class,
                () -> service.registerUser("valid@example.com", 15));
            assertTrue(ex.getMessage().contains("15"));
        }

        @Test
        @DisplayName("UnderageException is an unchecked RuntimeException")
        void isUncheckedRuntimeException() {
            RuntimeException ex = assertThrows(UnderageException.class,
                () -> service.registerUser("valid@example.com", 16));
            assertInstanceOf(RuntimeException.class, ex);
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Exception hierarchy tests
    // ══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Exception Hierarchy")
    class ExceptionHierarchyTests {

        @Test
        @DisplayName("InvalidEmailException extends Exception (checked)")
        void invalidEmailIsChecked() {
            assertTrue(Exception.class.isAssignableFrom(InvalidEmailException.class));
            assertFalse(RuntimeException.class.isAssignableFrom(InvalidEmailException.class));
        }

        @Test
        @DisplayName("UnderageException extends RuntimeException (unchecked)")
        void underageIsUnchecked() {
            assertTrue(RuntimeException.class.isAssignableFrom(UnderageException.class));
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Internal assert / invariant test
    // ══════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Internal Invariant Assertion")
    class InvariantTests {

        @Test
        @DisplayName("Disabled service throws AssertionError when assertions are enabled")
        void disabledServiceThrowsAssertionError() {
            // This test demonstrates the assert contract.
            // In production the JVM must be launched with -ea for assert to fire;
            // here we verify the service's disabled flag is set correctly and that
            // the logic path would trigger if assertions were enabled.
            RegistrationService disabledService = new RegistrationService(false);
            // When -ea is active this assertion fires; document the expected behavior:
            try {
                disabledService.registerUser("test@test.com", 25);
                // If -ea is not set, no error — assert is documented as present in code
            } catch (AssertionError e) {
                assertTrue(e.getMessage().contains("disabled"));
            } catch (InvalidEmailException e) {
                fail("Should not reach email validation when service is disabled.");
            }
        }
    }
}
